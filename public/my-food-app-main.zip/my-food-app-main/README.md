# my-food-app
My react food app application made as part of Udemy React - Maximilian course

This app implements the next Hooks: useState, useEffect, useContext, useRef and Portals.

This app also uses some basic effects.

- The application allows you to add food to the cart and then update or order it.
